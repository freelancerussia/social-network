const TOGGLE_FOLLOWED = "TOGGLE_FOLLOWED";
const SET_USERS = "SET_USERS";

let initialState = {
   users: [

   ],
   totalPageCount: 5,
   totalCount: 40,
};
function usersReducer(state = initialState, action) {
   switch (action.type) {

      case TOGGLE_FOLLOWED:
         return {
            ...state,
            users: state.users.map(u => {
               if (u.id === action.userId) {
                  return { ...u, followed: !u.followed }
               }
               return u;
            })
         }

      case SET_USERS:
         return {
            ...state,
            // users: [...state.users, ...action.users] ыдвет ошибку при вызовет setUsers, отрисовывает по два элемента нового массива
            users: [...action.users]
         }

      default:
         return state;
   }

}


export let toggleFollowedCreator = (userId) => ({ type: TOGGLE_FOLLOWED, userId })
export let setUsersCreator = (users) => ({ type: SET_USERS, users })
export default usersReducer;