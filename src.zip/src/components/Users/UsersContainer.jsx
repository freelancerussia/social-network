import { connect } from 'react-redux';
import { setUsersCreator, toggleFollowedCreator, } from '../../redux/usersReducer';
import Users from './Users';

let mapStateToProps = (state) => {
   return {
      users: state.usersPage.users,
      totalCount: state.totalCount,
      totoalPageCount: state.totoalPageCount,
   }
}
let mapDispatchToProps = (dispatch) => {
   return {
      toggleFollowed: (userId) => {
         dispatch(toggleFollowedCreator(userId))
      },
      setUsers: (users) => {
         dispatch(setUsersCreator(users))
      }
   }
}

export default connect(mapStateToProps, mapDispatchToProps)(Users);