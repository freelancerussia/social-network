import axios from 'axios';
import React from 'react';
import User from './User/User';
import classes from './Users.module.css';


class UsersC extends React.Component {

   componentDidMount() {
      axios.get('https://social-network.samuraijs.com/api/1.0/users')
         .then(response => {
            this.props.setUsers(response.data.items);
         });

   }



   renderUsers = () => {
      return this.props.users
         .map(user => {
            return (
               <User key={user.id} userPhoto={user.photos} userFollowed={user.followed} userId={user.id} userFullname={user.name}
                  userLocation={user.location} userStatus={user.status} toggleFollowed={this.props.toggleFollowed}></User>
            )
         })


   }

   render() {
      let pagesCount = Math.ceil(this.props.totalCount / this.props.totalPageCount);
      let pages = [];
      pages.map(p => {
         console.log(p);
         return <span>{p}</span>
      })
      return (
         <div className={classes.users}>
            <div>
               { }


            </div>
            {/* <button onClick={this.getUsers}>Get USERS</button> */}
            {this.renderUsers()}
         </div>)
   }



}
export default UsersC;