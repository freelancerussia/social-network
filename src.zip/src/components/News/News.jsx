import React from 'react';
import classes from './News.module.css'

function News() {
   return (
      <div className={classes.news}>
         news
      </div>

   );
}

export default News;