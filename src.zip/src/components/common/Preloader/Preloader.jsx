import preloader from '../../../assets/images/loading.gif'


let Preloader = () => {
   return (
      <div>
         <img src={preloader} alt="" />
      </div>
   )
}

export default Preloader;