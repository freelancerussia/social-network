import React from 'react';
import classes from './Settings.module.css'

function Settings() {
   return (
      <div className={classes.settings}>
         settings
      </div>

   );
}

export default Settings;