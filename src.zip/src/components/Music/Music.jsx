import React from 'react';
import classes from './Music.module.css'

function Music() {
   return (
      <div className={classes.music}>
         Music
      </div>

   );
}

export default Music;